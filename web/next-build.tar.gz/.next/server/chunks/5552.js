"use strict";exports.id=5552,exports.ids=[5552],exports.modules={15613:(a,b,c)=>{c.d(b,{Ee:()=>n,II:()=>o,qk:()=>p,uA:()=>m});var d=c(73024),e=c.n(d),f=c(76760),g=c.n(f),h=c(87550),i=c.n(h);function j(){return[g().resolve(process.cwd(),"..","bot","data"),g().resolve(process.cwd(),"bot","data"),g().resolve(process.cwd(),"..","data"),g().resolve(process.cwd(),"data")]}function k(){for(let a of j())if(e().existsSync(a))return a;return g().resolve(process.cwd(),"..","data")}function l(){for(let a of j()){let b=g().join(a,"bots");if(e().existsSync(b))return b}let a=k(),b=g().join(a,"bots");return e().existsSync(b)||e().mkdirSync(b,{recursive:!0}),b}function m(a){let b=j(),c="",d="",f="";if("bot-1"!==a){for(let f of b){let b=g().join(f,"bots",a),h=[g().join(b,"bot.db"),g().join(b,"data","bot.db"),g().join(b,"bot","data","bot.db")],i=h.find(a=>e().existsSync(a)&&e().statSync(a).size>0)||h.find(a=>e().existsSync(a));if(i){d=i,c=b;break}}for(let c of b){let b=g().join(c,"bots",a),d=[g().join(b,"session"),b,g().join(b,"data"),g().join(b,"bot","data")].find(a=>e().existsSync(g().join(a,"session.json")));if(d){f=d;break}}!c&&b[0]&&(c=g().join(b[0],"bots",a)),!d&&c&&(d=g().join(c,"bot.db")),!f&&c&&(f=g().join(c,"session"))}else for(let a of b){let b=g().join(a,"bots","bot-1"),h=[g().join(b,"bot.db"),g().join(a,"bot.db")].find(a=>e().existsSync(a));if(h){d=h,c=g().dirname(h),f=e().existsSync(g().join(c,"session"))?g().join(c,"session"):c;break}}c||(c=g().join(k(),"bots",a),d=g().join(c,"bot.db"),f=g().join(c,"session"));let h=g().join(c,"meta.json"),l={};if(e().existsSync(h))try{l=JSON.parse(e().readFileSync(h,"utf8"))}catch{}let m=l.zaloName||"",n=l.zaloId||"",o=l.avatarUrl||"",p=0,q=0;if(e().existsSync(d))try{let a=new(i())(d,{readonly:!0});try{let b=a.prepare("SELECT value FROM bot_state WHERE key = 'bot_display_name'").get();b?.value&&!m&&(m=b.value);let c=a.prepare("SELECT value FROM bot_state WHERE key = 'bot_zalo_id'").get();c?.value&&!n&&(n=c.value);let d=a.prepare("SELECT value FROM bot_state WHERE key = 'bot_avatar_url'").get();d?.value&&!o&&(o=d.value);try{let b=a.prepare("SELECT COUNT(*) AS total FROM bot_groups").get();if(b&&b.total>0)p=b.total;else{let b=a.prepare("SELECT COUNT(*) AS total FROM group_settings").get();p=b?.total||0}}catch{let b=a.prepare("SELECT COUNT(*) AS total FROM group_settings").get();p=b?.total||0}let e=a.prepare("SELECT COUNT(*) AS total FROM members WHERE is_active = 1").get();q=e?.total||0}catch{}a.close()}catch{}let r=[g().join(f,"session.json"),g().join(c,"session.json"),g().join(c,"session","session.json"),g().join(c,"data","session.json")],s=!1;for(let a of r)if(e().existsSync(a)&&e().statSync(a).size>10){s=!0;break}return{id:a,name:l.name||m||("bot-1"===a?"Bot 1 (Sen Ch\xfaa)":`Bot ${a.replace("bot-","")}`),avatarUrl:o,zaloName:m||l.name||"Zalo Bot",zaloId:n,isOnline:s,createdAt:l.createdAt||Date.now(),dbPath:d,sessionDir:f,groupCount:p,memberCount:q}}function n(){let a=j(),b=new Map,c=m("bot-1");for(let d of(c&&b.set("bot-1",c),a)){let a=g().join(d,"bots");if(e().existsSync(a)){for(let c of e().readdirSync(a,{withFileTypes:!0}))if(c.isDirectory()&&!c.name.startsWith(".")){let a=m(c.name);a&&b.set(c.name,a)}}}return 0===b.size&&b.set("bot-1",{id:"bot-1",name:"Bot 1 (Sen Ch\xfaa)",isOnline:!1,createdAt:Date.now(),dbPath:g().join(k(),"bot.db"),sessionDir:k(),groupCount:0,memberCount:0}),Array.from(b.values()).sort((a,b)=>a.id.localeCompare(b.id))}function o(a){let b=l(),c=n(),d=2;for(;c.some(a=>a.id===`bot-${d}`);)d++;let f=`bot-${d}`,h=g().join(b,f),i=g().join(h,"session");e().mkdirSync(h,{recursive:!0}),e().mkdirSync(i,{recursive:!0});let j={id:f,name:a.trim()||`Bot ${d}`,isOnline:!1,createdAt:Date.now(),dbPath:g().join(h,"bot.db"),sessionDir:i,groupCount:0,memberCount:0};return e().writeFileSync(g().join(h,"meta.json"),JSON.stringify(j,null,2),"utf8"),j}function p(a,b){let c=m(a);if(!c)return null;let d=l(),f=g().join(d,a);e().existsSync(f)||e().mkdirSync(f,{recursive:!0});let h={...c,...b};return e().writeFileSync(g().join(f,"meta.json"),JSON.stringify(h,null,2),"utf8"),h}},35552:(a,b,c)=>{c.d(b,{$B:()=>ab,$L:()=>ag,B:()=>r,B2:()=>M,Br:()=>H,Dl:()=>t,EK:()=>u,EO:()=>V,F_:()=>aj,Gu:()=>ad,ID:()=>F,JX:()=>N,Jf:()=>$,L4:()=>af,Mj:()=>G,Mm:()=>R,P0:()=>P,Qb:()=>D,Rt:()=>Y,Us:()=>E,_7:()=>K,ac:()=>Z,ex:()=>J,fB:()=>B,lR:()=>C,ls:()=>ak,nF:()=>ac,nU:()=>l,os:()=>T,pK:()=>s,pY:()=>w,py:()=>_,q8:()=>L,sD:()=>v,sO:()=>aa,sf:()=>U,uD:()=>ah,uF:()=>O,vw:()=>S,wb:()=>ae,z:()=>q});var d=c(87550),e=c.n(d),f=c(76760),g=c.n(f),h=c(73024),i=c.n(h),j=c(15613);let k=process.env.WEB_DB_PATH?.trim()||g().resolve(process.cwd(),"..","bot","data","bot.db");class l extends Error{}let m=`CASE i.type
    WHEN 'message' THEN 10
    WHEN 'image'   THEN 10
    WHEN 'video'   THEN 10
    WHEN 'vote'    THEN 3
    WHEN 'reaction' THEN 1
    WHEN 'manual'  THEN 1
    ELSE 1
  END`;function n(a){a.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version     TEXT PRIMARY KEY,
      applied_at  INTEGER NOT NULL,
      note        TEXT
    );

    CREATE TABLE IF NOT EXISTS bot_state (
      key         TEXT PRIMARY KEY,
      value       TEXT NOT NULL,
      updated_at  INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bot_groups (
      group_id       TEXT PRIMARY KEY,
      name           TEXT NOT NULL,
      total_members  INTEGER NOT NULL DEFAULT 0,
      mode           TEXT NOT NULL DEFAULT 'interactive',
      persona        TEXT NOT NULL DEFAULT 'humorous',
      custom_prompt  TEXT NOT NULL DEFAULT '',
      bot_name       TEXT NOT NULL DEFAULT 'Sen Ch\xfaa',
      welcome_msg    TEXT NOT NULL DEFAULT '',
      weather_auto   INTEGER NOT NULL DEFAULT 0,
      weather_time   TEXT NOT NULL DEFAULT '07:00',
      weather_city   TEXT NOT NULL DEFAULT 'Hồ Ch\xed Minh',
      is_active      INTEGER NOT NULL DEFAULT 0,
      creator_id     TEXT,
      updated_at     INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS group_settings (
      group_id       TEXT PRIMARY KEY,
      mode           TEXT NOT NULL DEFAULT 'interactive',
      updated_at     INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bot_errors (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      source      TEXT NOT NULL,
      code        TEXT NOT NULL DEFAULT '',
      message     TEXT NOT NULL,
      detail      TEXT,
      created_at  INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS members (
      zalo_user_id   TEXT PRIMARY KEY,
      display_name   TEXT NOT NULL DEFAULT '',
      role           TEXT NOT NULL DEFAULT 'member',
      joined_at      INTEGER,
      first_seen_at  INTEGER NOT NULL,
      is_active      INTEGER NOT NULL DEFAULT 1,
      left_at        INTEGER,
      group_id       TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS group_members (
      zalo_user_id   TEXT NOT NULL,
      group_id       TEXT NOT NULL,
      display_name   TEXT NOT NULL DEFAULT '',
      role           TEXT NOT NULL DEFAULT 'member',
      joined_at      INTEGER,
      first_seen_at  INTEGER NOT NULL,
      is_active      INTEGER NOT NULL DEFAULT 1,
      left_at        INTEGER,
      PRIMARY KEY (zalo_user_id, group_id)
    );

    CREATE TABLE IF NOT EXISTS member_sync_runs (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      requested_by   TEXT NOT NULL DEFAULT 'system',
      started_at     INTEGER NOT NULL,
      finished_at    INTEGER,
      status         TEXT NOT NULL,
      group_id       TEXT,
      group_name     TEXT,
      member_count   INTEGER,
      snapshot_count INTEGER,
      upserted       INTEGER,
      marked_left    INTEGER,
      error          TEXT
    );

    CREATE TABLE IF NOT EXISTS member_events (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      zalo_user_id   TEXT NOT NULL,
      display_name   TEXT NOT NULL DEFAULT '',
      role           TEXT,
      event_type     TEXT NOT NULL,
      source         TEXT NOT NULL,
      sync_run_id    INTEGER,
      ts             INTEGER NOT NULL,
      note           TEXT,
      group_id       TEXT,
      FOREIGN KEY (sync_run_id) REFERENCES member_sync_runs(id)
    );

    CREATE TABLE IF NOT EXISTS interactions (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      zalo_user_id   TEXT NOT NULL,
      type           TEXT NOT NULL,
      ts             INTEGER NOT NULL,
      source         TEXT NOT NULL DEFAULT 'listener',
      thread_id      TEXT NOT NULL DEFAULT '',
      FOREIGN KEY (zalo_user_id) REFERENCES members(zalo_user_id)
    );

    CREATE TABLE IF NOT EXISTS group_messages (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      thread_id      TEXT NOT NULL,
      message_id     TEXT NOT NULL,
      zalo_user_id   TEXT NOT NULL,
      display_name   TEXT NOT NULL DEFAULT '',
      text           TEXT NOT NULL,
      msg_type       TEXT NOT NULL DEFAULT '',
      ts             INTEGER NOT NULL,
      is_self        INTEGER NOT NULL DEFAULT 0,
      source         TEXT NOT NULL DEFAULT 'listener',
      created_at     INTEGER NOT NULL,
      deleted_at     INTEGER,
      deleted_source TEXT NOT NULL DEFAULT '',
      FOREIGN KEY (zalo_user_id) REFERENCES members(zalo_user_id),
      UNIQUE (thread_id, message_id)
    );

    CREATE TABLE IF NOT EXISTS group_media_events (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      thread_id      TEXT NOT NULL,
      message_id     TEXT NOT NULL,
      zalo_user_id   TEXT NOT NULL,
      display_name   TEXT NOT NULL DEFAULT '',
      media_type     TEXT NOT NULL,
      media_count    INTEGER NOT NULL DEFAULT 1,
      msg_type       TEXT NOT NULL DEFAULT '',
      ts             INTEGER NOT NULL,
      is_self        INTEGER NOT NULL DEFAULT 0,
      source         TEXT NOT NULL DEFAULT 'listener',
      created_at     INTEGER NOT NULL,
      deleted_at     INTEGER,
      deleted_source TEXT NOT NULL DEFAULT '',
      media_url      TEXT NOT NULL DEFAULT '',
      local_path     TEXT NOT NULL DEFAULT '',
      ocr_text       TEXT NOT NULL DEFAULT '',
      ocr_at         INTEGER
    );

    CREATE TABLE IF NOT EXISTS daily_summaries (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      day_date          TEXT NOT NULL,
      day_label         TEXT NOT NULL,
      day_start_ts      INTEGER NOT NULL,
      thread_id         TEXT NOT NULL DEFAULT '',
      summary_text      TEXT NOT NULL,
      parts_json        TEXT NOT NULL,
      total_messages    INTEGER NOT NULL,
      included_messages INTEGER NOT NULL,
      unique_senders    INTEGER NOT NULL,
      images            INTEGER NOT NULL DEFAULT 0,
      videos            INTEGER NOT NULL DEFAULT 0,
      top_senders_json  TEXT NOT NULL DEFAULT '[]',
      model             TEXT NOT NULL,
      transcript_chars  INTEGER NOT NULL,
      prompt_tokens     INTEGER,
      completion_tokens INTEGER,
      cost_usd          REAL,
      duration_ms       INTEGER NOT NULL,
      sent_zalo         INTEGER NOT NULL DEFAULT 0,
      sent_telegram     INTEGER NOT NULL DEFAULT 0,
      created_at        INTEGER NOT NULL,
      UNIQUE(day_date, thread_id)
    );

    CREATE TABLE IF NOT EXISTS cleanup_draft_plans (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at        INTEGER NOT NULL,
      target_count      INTEGER NOT NULL,
      member_count      INTEGER NOT NULL,
      over_target       INTEGER NOT NULL,
      max_kicks         INTEGER NOT NULL,
      candidate_count   INTEGER NOT NULL,
      grace_count       INTEGER NOT NULL,
      removable_count   INTEGER NOT NULL,
      note              TEXT
    );

    CREATE TABLE IF NOT EXISTS cleanup_draft_plan_items (
      id                 INTEGER PRIMARY KEY AUTOINCREMENT,
      draft_plan_id      INTEGER NOT NULL,
      zalo_user_id       TEXT NOT NULL,
      display_name       TEXT NOT NULL DEFAULT '',
      interaction_count  INTEGER NOT NULL DEFAULT 0,
      last_interaction   INTEGER,
      warning_count      INTEGER NOT NULL DEFAULT 0,
      rank               INTEGER NOT NULL,
      action             TEXT NOT NULL,
      reason             TEXT NOT NULL DEFAULT '',
      FOREIGN KEY (draft_plan_id) REFERENCES cleanup_draft_plans(id),
      UNIQUE (draft_plan_id, zalo_user_id)
    );

    CREATE TABLE IF NOT EXISTS group_knowledge (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      thread_id    TEXT NOT NULL,
      title        TEXT NOT NULL DEFAULT '',
      file_name    TEXT NOT NULL DEFAULT '',
      file_type    TEXT NOT NULL DEFAULT 'document',
      file_url     TEXT,
      content_text TEXT NOT NULL,
      summary      TEXT,
      sender_name  TEXT NOT NULL DEFAULT '',
      created_at   INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bot_friends (
      user_id        TEXT PRIMARY KEY,
      display_name   TEXT NOT NULL DEFAULT '',
      avatar         TEXT NOT NULL DEFAULT '',
      allow_direct   INTEGER NOT NULL DEFAULT 0,
      updated_at     INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_bot_friends_allow ON bot_friends(allow_direct);
  `)}let o=new Map;function p(a="bot-1"){let b=process.env.HOME||"/home/congtrien125",c=String(process.env.PORT||process.env.WEB_PORT||"");if("3002"===c||"3001"===c||"bot-2"===process.env.BOT_ID||process.env.WEB_DB_PATH?.includes("bot-2")||"bot-2"===a){for(let a of[g().resolve(b,"zalo-bot-2","bot","data","bot.db"),g().resolve(b,"zalo-bot-2","data","bot.db"),g().resolve(process.cwd(),"..","bot","data","bot.db"),g().resolve(process.cwd(),"bot","data","bot.db"),g().resolve(b,"zalo-bot","data","bots","bot-2","bot.db"),g().resolve(b,"zalo-bot","bot","data","bots","bot-2","bot.db")])if(i().existsSync(a)&&i().statSync(a).size>0){let b=o.get(a);if(b&&b.open)return b;let c=new(e())(a);return c.pragma("busy_timeout = 5000"),c.pragma("foreign_keys = ON"),n(c),o.set(a,c),c}}if(process.env.WEB_DB_PATH?.trim()&&i().existsSync(process.env.WEB_DB_PATH.trim())){let a=process.env.WEB_DB_PATH.trim(),b=o.get(a);if(b&&b.open)return b;let c=new(e())(a);return c.pragma("busy_timeout = 5000"),c.pragma("foreign_keys = ON"),n(c),o.set(a,c),c}let d=a||"bot-1",f=o.get(d);if(f&&f.open)return f;let h=(0,j.uA)(d),l=h?.dbPath;if(!l||!i().existsSync(l)){for(let a of"bot-1"===d?[g().resolve(b,"zalo-bot","bot","data","bot.db"),g().resolve(b,"zalo-bot","data","bot.db"),g().resolve(process.cwd(),"..","bot","data","bot.db"),g().resolve(process.cwd(),"bot","data","bot.db"),g().resolve(process.cwd(),"data","bot.db"),k]:[g().resolve(b,"zalo-bot-2","bot","data","bot.db"),g().resolve(b,"zalo-bot-2","data","bot.db"),g().resolve(process.cwd(),"..","bot","data","bot.db"),g().resolve(b,"zalo-bot","data","bots",d,"bot.db"),g().resolve(b,"zalo-bot","bot","data","bots",d,"bot.db"),g().resolve(process.cwd(),"..","data","bots",d,"bot.db"),g().resolve(process.cwd(),"data","bots",d,"bot.db")])if(i().existsSync(a)&&i().statSync(a).size>0){l=a;break}}l||(l="bot-1"===d?k:g().resolve(b,"zalo-bot-2","bot","data","bot.db")),i().existsSync(l)||i().mkdirSync(g().dirname(l),{recursive:!0});let m=new(e())(l);return m.pragma("busy_timeout = 5000"),m.pragma("foreign_keys = ON"),n(m),o.set(d,m),m}function q(a="bot-1"){let b=a||"bot-1",c=process.env.HOME||"/home/congtrien125",d=(0,j.uA)(b);if(d?.dbPath&&i().existsSync(d.dbPath))return!0;if("bot-1"!==b){let a=g().resolve(c,"zalo-bot","data","bots",b,"bot.db");if(i().existsSync(a))return!0}return i().existsSync(k)}function r(a,b){let c=(a||"").trim(),d=p(b);if(!c||"all"===c)return d.prepare("SELECT COUNT(*) AS n FROM members WHERE is_active = 1").get().n;try{if(d.prepare("SELECT 1 FROM group_members WHERE group_id = ? LIMIT 1").get(c))return d.prepare("SELECT COUNT(*) AS n FROM group_members WHERE is_active = 1 AND group_id = @targetGroupId").get({targetGroupId:c}).n}catch{}return d.prepare("SELECT COUNT(*) AS n FROM members WHERE is_active = 1 AND (group_id = @targetGroupId OR group_id = '' OR group_id IS NULL)").get({targetGroupId:c}).n}function s(a,b){let c=(a||"").trim(),d=p(b),e="members",f="WHERE is_active = 1";if(c&&"all"!==c){try{d.prepare("SELECT 1 FROM group_members WHERE group_id = ? LIMIT 1").get(c)&&(e="group_members")}catch{}f="WHERE is_active = 1 AND (group_id = @targetGroupId OR group_id = '' OR group_id IS NULL)"}let g=d.prepare(`SELECT role, COUNT(*) AS n FROM ${e} ${f} GROUP BY role`).all({targetGroupId:c}),h={owner:0,admin:0,member:0};for(let a of g)("owner"===a.role||"admin"===a.role||"member"===a.role)&&(h[a.role]=a.n);return h}function t(a,b){let c=(a||"").trim(),d=p(b);return c&&"all"!==c?"1913869945242410752"===c?d.prepare("SELECT COUNT(*) AS n FROM interactions WHERE thread_id = @targetThreadId OR thread_id = '' OR thread_id IS NULL").get({targetThreadId:c}).n:d.prepare("SELECT COUNT(*) AS n FROM interactions WHERE thread_id = @targetThreadId").get({targetThreadId:c}).n:d.prepare("SELECT COUNT(*) AS n FROM interactions").get().n}function u(a){let b=p(a);try{if(x("bot_groups",a)){let a=b.prepare("SELECT group_id, name, total_members FROM bot_groups ORDER BY total_members DESC").all();if(a.length>0)return a.map(a=>({id:a.group_id,name:a.name,memberCount:a.total_members}))}}catch(a){console.warn("Lỗi khi đọc bot_groups:",a)}let c=new Map;try{if(x("member_sync_runs",a))for(let a of b.prepare(`SELECT group_id, group_name, member_count
           FROM member_sync_runs
           WHERE group_id IS NOT NULL AND group_id != ''
           ORDER BY id DESC`).all()){if(!a.group_id)continue;let b=c.get(a.group_id);b?(a.group_name&&a.group_name.trim()&&(b.name=a.group_name),a.member_count&&(b.memberCount=a.member_count)):c.set(a.group_id,{id:a.group_id,name:a.group_name||`Nh\xf3m ${a.group_id}`,memberCount:a.member_count})}}catch(a){console.warn("Lỗi khi đọc member_sync_runs:",a)}if(c.size>0)return Array.from(c.values());for(let a of(process.env.GROUP_ID||"").split(",").map(a=>a.trim()).filter(Boolean))c.set(a,{id:a,name:`Nh\xf3m ${a}`});return Array.from(c.values())}function v(a,b=50,c,d){let e=Date.now(),f=(c||"").trim(),g="";f&&"all"!==f&&(g="1913869945242410752"===f?"AND (i.thread_id = @targetThreadId OR i.thread_id = '' OR i.thread_id IS NULL)":"AND i.thread_id = @targetThreadId");let h=p(d),i="";return x("leaderboard_exclusions",d)&&(i=`AND m.zalo_user_id NOT IN (
      SELECT zalo_user_id FROM leaderboard_exclusions 
      WHERE group_id = '' OR group_id = @targetThreadId OR @targetThreadId = ''
    )`),h.prepare(`SELECT
         m.display_name,
         SUM(${m}) AS interaction_count,
         SUM(CASE WHEN i.type = 'message' THEN 1 ELSE 0 END) AS message_count,
         SUM(CASE WHEN i.type = 'reaction' THEN 1 ELSE 0 END) AS reaction_count,
         SUM(CASE WHEN i.type = 'vote' THEN 1 ELSE 0 END) AS vote_count,
         SUM(CASE WHEN i.type NOT IN ('message', 'reaction', 'vote') THEN 1 ELSE 0 END) AS other_count,
         MAX(i.ts) AS last_interaction
       FROM interactions i
       JOIN members m ON m.zalo_user_id = i.zalo_user_id
       WHERE m.is_active = 1
         AND i.ts >= @since
         ${g}
         AND LOWER(m.display_name) NOT LIKE '%sen ch\xfaa%'
         AND LOWER(m.display_name) NOT LIKE '%sen chua%'
         AND LOWER(m.display_name) NOT LIKE '%mộc mi\xean%'
         AND LOWER(m.display_name) NOT LIKE '%moc mien%'
         ${i}
       GROUP BY i.zalo_user_id, m.display_name
       ORDER BY interaction_count DESC, last_interaction DESC, LOWER(m.display_name) ASC
       LIMIT @limit`).all({since:"7d"===a?e-6048e5:"30d"===a?e-2592e6:0,targetThreadId:f,limit:Math.min(Math.max(b,1),100)}).map((a,b)=>({...a,rank:b+1}))}function w(a=5e3){return p().prepare(`SELECT zalo_user_id AS id, display_name AS displayName, role
       FROM members
       WHERE is_active = 1
       ORDER BY LOWER(display_name) ASC, zalo_user_id ASC
       LIMIT @limit`).all({limit:Math.min(Math.max(a,1),5e3)})}function x(a,b){return void 0!==p(b).prepare("SELECT 1 AS ok FROM sqlite_master WHERE type = 'table' AND name = @name").get({name:a})}function y(a){let b=(a||"").trim(),c="",d="",e="members";if(b&&"all"!==b){d=`AND (i.thread_id = '${b}')`,c=`AND (m.group_id = '${b}')`;try{p().prepare("SELECT 1 FROM group_members WHERE group_id = ? LIMIT 1").get(b)&&(e="group_members")}catch{}}return`WITH member_stats AS (
    SELECT m.zalo_user_id, m.display_name, m.role, m.joined_at, m.first_seen_at,
           COALESCE(SUM(${m}), 0) AS interaction_count,
           MAX(i.ts) AS last_interaction,
           COALESCE(cw.warning_count, 0) AS warning_count,
           cw.last_warned_at AS last_warned_at
    FROM ${e} m
    LEFT JOIN interactions i ON i.zalo_user_id = m.zalo_user_id ${d}
    LEFT JOIN cleanup_warnings cw ON cw.zalo_user_id = m.zalo_user_id
    WHERE m.is_active = 1
      ${c}
      AND (@q = '' OR LOWER(m.display_name) LIKE @like OR LOWER(m.zalo_user_id) LIKE @like)
    GROUP BY m.zalo_user_id
  )`}function z(a){let b=[];switch(a.role&&"all"!==a.role&&b.push("role = @role"),a.activity){case"zero":b.push("interaction_count = 0");break;case"never":b.push("last_interaction IS NULL");break;case"recent":b.push("last_interaction >= @since30");break;case"inactive7":b.push("(last_interaction IS NULL OR last_interaction < @since7)");break;case"inactive30":b.push("(last_interaction IS NULL OR last_interaction < @since30)");break;case"inactive90":b.push("(last_interaction IS NULL OR last_interaction < @since90)");break;case"warned":b.push("warning_count > 0")}return b.length?`WHERE ${b.join(" AND ")}`:""}function A(a){let b=a.q?.trim().toLowerCase()??"";return{q:b,like:`%${b}%`,role:a.role??"all",since7:Date.now()-6048e5,since30:Date.now()-2592e6,since90:Date.now()-7776e6,limit:Math.min(Math.max(a.limit??2e3,1),5e3)}}function B(a={}){return p().prepare(`${y(a.threadId)}
       SELECT *
       FROM member_stats
       ${z(a)}
       ORDER BY ${function(a){switch(a){case"interactions":return"interaction_count DESC, last_interaction DESC";case"last":return"last_interaction IS NULL DESC, last_interaction ASC, interaction_count ASC";case"name":return"LOWER(display_name) ASC, zalo_user_id ASC";case"joined":return"joined_at IS NULL ASC, joined_at DESC";case"warnings":return"warning_count DESC, last_warned_at DESC, interaction_count ASC";default:return"role = 'member' DESC, interaction_count ASC, last_interaction IS NULL DESC, last_interaction ASC"}}(a.sort)}
       LIMIT @limit`).all(A(a))}function C(a={}){return p().prepare(`${y(a.threadId)}
       SELECT
         COUNT(*) AS total,
         COALESCE(SUM(CASE WHEN role = 'owner' THEN 1 ELSE 0 END), 0) AS owner,
         COALESCE(SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END), 0) AS admin,
         COALESCE(SUM(CASE WHEN role = 'member' THEN 1 ELSE 0 END), 0) AS member,
         COALESCE(SUM(CASE WHEN interaction_count = 0 THEN 1 ELSE 0 END), 0) AS zero_interactions,
         COALESCE(SUM(CASE WHEN last_interaction IS NULL THEN 1 ELSE 0 END), 0) AS never_interacted,
         COALESCE(SUM(CASE WHEN last_interaction IS NULL OR last_interaction < @since30 THEN 1 ELSE 0 END), 0) AS inactive_30d,
         COALESCE(SUM(CASE WHEN last_interaction IS NULL OR last_interaction < @since90 THEN 1 ELSE 0 END), 0) AS inactive_90d,
         COALESCE(SUM(CASE WHEN warning_count > 0 THEN 1 ELSE 0 END), 0) AS warned,
         COALESCE(SUM(CASE WHEN role = 'member' AND interaction_count = 0 AND warning_count > 0 THEN 1 ELSE 0 END), 0) AS removable_candidates,
         COALESCE(SUM(interaction_count), 0) AS total_interactions
       FROM member_stats
       ${z(a)}`).get(A(a))}function D(a=500){return p().prepare("SELECT * FROM removals ORDER BY removed_at DESC LIMIT @limit").all({limit:a})}function E(a=100){return p().prepare("SELECT * FROM scan_runs ORDER BY id DESC LIMIT @limit").all({limit:a})}function F(){return p().prepare(`SELECT r.*
       FROM scan_runs r
       WHERE EXISTS (SELECT 1 FROM cleanup_plan_items i WHERE i.scan_run_id = r.id)
       ORDER BY r.id DESC
       LIMIT 1`).get()}function G(a){return p().prepare(`SELECT *
       FROM cleanup_plan_items
       WHERE scan_run_id = @scanRunId
       ORDER BY rank ASC`).all({scanRunId:a})}function H(a){return p().prepare(`UPDATE cleanup_plan_items
       SET status = @status, error = @error, updated_at = @now
       WHERE id = @id
         AND status IN ('planned', 'skipped', 'failed')
         AND EXISTS (
           SELECT 1
           FROM scan_runs r
           WHERE r.id = cleanup_plan_items.scan_run_id
             AND r.status IN ('planned', 'pending_approval', 'failed')
         )`).run({id:a.id,status:a.status,error:"skipped"===a.status?a.error??"Admin bỏ chọn tr\xean dashboard.":null,now:Date.now()}).changes>0}function I(a){let b=ad(a);if(!b)return null;try{return JSON.parse(b)}catch{return null}}function J(){return I("bot_health")}function K(){return I("permission_check")}function L(a,b=12e4){return!!(a?.heartbeatAt&&Date.now()-a.heartbeatAt<=b)}function M(a=100,b){return x("bot_errors",b)?p(b).prepare(`SELECT *
       FROM bot_errors
       ORDER BY created_at DESC, id DESC
       LIMIT @limit`).all({limit:Math.min(Math.max(a,1),500)}):[]}function N(a=20,b){return x("schema_migrations",b)?p(b).prepare(`SELECT *
       FROM schema_migrations
       ORDER BY applied_at DESC
       LIMIT @limit`).all({limit:Math.min(Math.max(a,1),100)}):[]}function O(){if(x("member_sync_runs"))return p().prepare("SELECT * FROM member_sync_runs ORDER BY id DESC LIMIT 1").get()}function P(){return x("member_sync_runs")?p().prepare(`SELECT * FROM member_sync_runs
       WHERE group_id IS NOT NULL AND group_id != ''
       GROUP BY group_id
       HAVING id = MAX(id)
       ORDER BY id DESC`).all():[]}function Q(a){let b=[],c={eventType:a.eventType??"all",source:a.source??"all",from:a.from??null,to:a.to??null,limit:Math.min(Math.max(a.limit??200,1),5e3)};return a.eventType&&"all"!==a.eventType&&b.push("event_type = @eventType"),a.source&&"all"!==a.source&&b.push("source = @source"),a.from&&b.push("ts >= @from"),a.to&&b.push("ts <= @to"),a.threadId&&"all"!==a.threadId&&(b.push("(group_id = @threadId OR sync_run_id IN (SELECT id FROM member_sync_runs WHERE group_id = @threadId))"),c.threadId=a.threadId),{sql:b.length?`WHERE ${b.join(" AND ")}`:"",params:c}}function R(a=200){if(!x("member_events"))return[];let b=Q("number"==typeof a?{limit:a}:a);return p().prepare(`SELECT *
       FROM member_events
       ${b.sql}
       ORDER BY ts DESC, id DESC
       LIMIT @limit`).all(b.params)}function S(a={}){if(!x("member_events"))return 0;let b=Q(a);return p().prepare(`SELECT COUNT(*) AS n FROM member_events ${b.sql}`).get(b.params).n}function T(a){let b=(a.threadId||"").trim(),c="members",d="",e="";if(b&&"all"!==b){e=`AND (i.thread_id = '${b}')`,d=`AND (m.group_id = '${b}')`;try{p().prepare("SELECT 1 FROM group_members WHERE group_id = ? LIMIT 1").get(b)&&(c="group_members")}catch{}}let f=r(b||void 0),g=Math.max(0,f-a.target),h=Math.min(g,a.maxKicks),i=[...new Set(a.vipIds??[])].filter(Boolean),j=(()=>{let b=new Date(a.now??Date.now());return new Date(b.getFullYear(),b.getMonth(),1,0,0,0,0).getTime()})(),k=Object.fromEntries(i.map((a,b)=>[`vip${b}`,a])),l=i.length?`AND m.zalo_user_id NOT IN (${i.map((a,b)=>`@vip${b}`).join(", ")})`:"",n={cycleStart:j,limit:Math.max(h,1),...k},o=`WITH member_stats AS (
    SELECT m.zalo_user_id, m.display_name, m.role, m.joined_at, m.first_seen_at,
           COALESCE(SUM(${m}), 0) AS interaction_count,
           MAX(i.ts) AS last_interaction,
           COALESCE(cw.warning_count, 0) AS warning_count,
           cw.last_warned_at AS last_warned_at
    FROM ${c} m
    LEFT JOIN interactions i ON i.zalo_user_id = m.zalo_user_id ${e}
    LEFT JOIN cleanup_warnings cw ON cw.zalo_user_id = m.zalo_user_id
    WHERE m.is_active = 1
      ${d}
      AND m.role = 'member'
      AND m.first_seen_at < @cycleStart
      AND (m.joined_at IS NULL OR m.joined_at < @cycleStart)
      ${l}
    GROUP BY m.zalo_user_id
  )`,q=p().prepare(`${o} SELECT COUNT(*) AS n FROM member_stats`).get(n),s=(h>0?p().prepare(`${o}
             SELECT *
             FROM member_stats
             ORDER BY interaction_count ASC, last_interaction ASC
             LIMIT @limit`).all(n):[]).map((a,b)=>{let c=0===a.interaction_count&&0===a.warning_count?"grace":"remove";return{...a,rank:b+1,action:c,reason:0===a.interaction_count?0===a.warning_count?"0 tương t\xe1c, kỳ đầu sẽ \xe2n hạn":"0 tương t\xe1c, đ\xe3 từng cảnh b\xe1o":`${a.interaction_count} tương t\xe1c`}});return{total:f,target:a.target,overTarget:g,maxKicks:a.maxKicks,needToReview:h,eligibleCount:q.n,graceCount:s.filter(a=>"grace"===a.action).length,removableCount:s.filter(a=>"remove"===a.action).length,candidates:s}}function U(a,b){let c=Date.now(),d=p();return d.transaction(()=>{let e=Number(d.prepare(`INSERT INTO cleanup_draft_plans
           (created_at, target_count, member_count, over_target, max_kicks,
            candidate_count, grace_count, removable_count, note)
         VALUES
           (@createdAt, @target, @total, @overTarget, @maxKicks,
            @candidateCount, @graceCount, @removableCount, @note)`).run({createdAt:c,target:a.target,total:a.total,overTarget:a.overTarget,maxKicks:a.maxKicks,candidateCount:a.candidates.length,graceCount:a.graceCount,removableCount:a.removableCount,note:b??null}).lastInsertRowid),f=d.prepare(`INSERT INTO cleanup_draft_plan_items
         (draft_plan_id, zalo_user_id, display_name, interaction_count, last_interaction,
          warning_count, rank, action, reason)
       VALUES
         (@draftPlanId, @zaloUserId, @displayName, @interactionCount, @lastInteraction,
          @warningCount, @rank, @action, @reason)`);for(let b of a.candidates)f.run({draftPlanId:e,zaloUserId:b.zalo_user_id,displayName:b.display_name,interactionCount:b.interaction_count,lastInteraction:b.last_interaction,warningCount:b.warning_count,rank:b.rank,action:b.action,reason:b.reason});return e})()}function V(){let a=p().prepare("SELECT * FROM cleanup_draft_plans ORDER BY id DESC LIMIT 1").get();if(!a)return null;let b=p().prepare(`SELECT
         COALESCE(SUM(CASE WHEN m.is_active = 1 THEN 1 ELSE 0 END), 0) AS stillActive,
         COALESCE(SUM(CASE WHEN m.is_active IS NULL OR m.is_active != 1 THEN 1 ELSE 0 END), 0) AS noLongerActive,
         COALESCE(SUM(CASE WHEN cur.interaction_count > i.interaction_count THEN 1 ELSE 0 END), 0) AS interactedMore
       FROM cleanup_draft_plan_items i
       LEFT JOIN members m ON m.zalo_user_id = i.zalo_user_id
       LEFT JOIN (
         SELECT zalo_user_id, COUNT(*) AS interaction_count
         FROM interactions
         GROUP BY zalo_user_id
       ) cur ON cur.zalo_user_id = i.zalo_user_id
       WHERE i.draft_plan_id = @id`).get({id:a.id});return{plan:a,...b}}function W(a){let b=[],c=a.q?.trim().toLowerCase()??"",d=(a.threadId||"").trim(),e={q:c,like:`%${c}%`,from:a.from??null,to:a.to??null,threadId:d,limit:Math.min(Math.max(a.limit??200,1),5e3)};return c&&b.push("(LOWER(text) LIKE @like OR LOWER(display_name) LIKE @like OR zalo_user_id LIKE @like)"),a.from&&b.push("ts >= @from"),a.to&&b.push("ts <= @to"),"self"===a.self&&b.push("is_self = 1"),"member"===a.self&&b.push("is_self = 0"),d&&"all"!==d&&("1913869945242410752"===d?b.push("(thread_id = @threadId OR thread_id = '' OR thread_id IS NULL)"):b.push("thread_id = @threadId")),{sql:b.length?`WHERE ${b.join(" AND ")}`:"",params:e}}function X(a){let b=[],c=a.q?.trim().toLowerCase()??"",d=(a.threadId||"").trim(),e={q:c,like:`%${c}%`,from:a.from??null,to:a.to??null,threadId:d,limit:Math.min(Math.max(a.limit??200,1),5e3)};return c&&b.push("(LOWER(display_name) LIKE @like OR zalo_user_id LIKE @like OR media_type LIKE @like)"),a.from&&b.push("ts >= @from"),a.to&&b.push("ts <= @to"),"self"===a.self&&b.push("is_self = 1"),"member"===a.self&&b.push("is_self = 0"),d&&"all"!==d&&("1913869945242410752"===d?b.push("(thread_id = @threadId OR thread_id = '' OR thread_id IS NULL)"):b.push("thread_id = @threadId")),{sql:b.length?`WHERE ${b.join(" AND ")}`:"",params:e}}function Y(a={},b){if(!x("group_messages",b))return 0;let c=W(a),d=p(b).prepare(`SELECT COUNT(*) AS n FROM group_messages ${c.sql}`).get(c.params);return d?.n||0}function Z(a={},b){if(!x("group_messages",b))return[];let c=W(a);return p(b).prepare(`SELECT *
       FROM group_messages
       ${c.sql}
       ORDER BY ts DESC, id DESC
       LIMIT @limit`).all(c.params)}function $(a={},b){if(!x("group_media_events",b))return{imageEvents:0,imageCount:0,videoEvents:0,videoCount:0};let c=X(a);return p(b).prepare(`SELECT
         COALESCE(SUM(CASE WHEN media_type = 'image' THEN 1 ELSE 0 END), 0) AS imageEvents,
         COALESCE(SUM(CASE WHEN media_type = 'image' THEN media_count ELSE 0 END), 0) AS imageCount,
         COALESCE(SUM(CASE WHEN media_type = 'video' THEN 1 ELSE 0 END), 0) AS videoEvents,
         COALESCE(SUM(CASE WHEN media_type = 'video' THEN media_count ELSE 0 END), 0) AS videoCount
       FROM group_media_events
       ${c.sql}`).get(c.params)||{imageEvents:0,imageCount:0,videoEvents:0,videoCount:0}}function _(a={},b){if(!x("group_media_events",b))return[];let c=X(a);return p(b).prepare(`SELECT *
       FROM group_media_events
       ${c.sql}
       ORDER BY ts DESC, id DESC
       LIMIT @limit`).all(c.params)}function aa(a={},b){if(!x("daily_summaries",b))return[];let c=function(a){let b=[],c=a.q?.trim().toLowerCase()??"",d=(a.threadId||"").trim(),e={like:`%${c}%`,from:a.from??null,to:a.to??null,threadId:d,limit:Math.min(Math.max(a.limit??100,1),1e3)};return c&&b.push("(LOWER(summary_text) LIKE @like OR day_label LIKE @like OR day_date LIKE @like)"),a.from&&b.push("day_start_ts >= @from"),a.to&&b.push("day_start_ts <= @to"),d&&"all"!==d&&("1913869945242410752"===d?b.push("(thread_id = @threadId OR thread_id = '' OR thread_id IS NULL)"):b.push("thread_id = @threadId")),{sql:b.length?`WHERE ${b.join(" AND ")}`:"",params:e}}(a);return p(b).prepare(`SELECT *
       FROM daily_summaries
       ${c.sql}
       ORDER BY day_date DESC
       LIMIT @limit`).all(c.params)}function ab(a=1e3){return x("daily_summaries")?p().prepare(`SELECT day_date, day_label, total_messages, unique_senders, images, videos,
              source, created_at, length(summary_text) AS summary_chars
       FROM daily_summaries
       ORDER BY day_date DESC
       LIMIT @limit`).all({limit:Math.min(Math.max(a,1),5e3)}):[]}function ac(a){if(x("daily_summaries"))return p().prepare("SELECT * FROM daily_summaries WHERE day_date = @dayDate").get({dayDate:a})}function ad(a){let b=p().prepare("SELECT value FROM bot_state WHERE key = @key").get({key:a});return b?.value}function ae(a,b){let c=Date.now();p().prepare(`INSERT INTO bot_state (key, value, updated_at) VALUES (@key, @value, @now)
       ON CONFLICT(key) DO UPDATE SET value = @value, updated_at = @now`).run({key:a,value:b,now:c})}function af(a="bot-1"){try{if(!x("bot_friends"))return[];return p(a).prepare(`SELECT user_id as userId, display_name as displayName, avatar,
                allow_direct as allowDirect, updated_at as updatedAt
         FROM bot_friends
         ORDER BY allow_direct DESC, display_name COLLATE NOCASE ASC`).all().map(a=>({userId:a.userId,displayName:a.displayName,avatar:a.avatar,allowDirect:!!a.allowDirect,updatedAt:a.updatedAt}))}catch(a){return console.error("[web/db] listBotFriends error:",a),[]}}function ag(a,b,c="bot-1"){try{if(!x("bot_friends"))return!1;return p(c).prepare("UPDATE bot_friends SET allow_direct = ?, updated_at = ? WHERE user_id = ?").run(+!!b,Date.now(),a).changes>0}catch(a){return console.error("[web/db] setFriendAllowDirect error:",a),!1}}function ah(a="bot-1"){try{if(!x("bot_state"))return{};let b=p(a).prepare("SELECT value, updated_at FROM bot_state WHERE key = 'friend_sync'").get();if(!b)return{};let c=JSON.parse(b.value);return{lastSync:{total:Number(c.total??0),upserted:Number(c.upserted??0),updatedAt:Number(c.updatedAt??b.updated_at)}}}catch{return{}}}let ai="Xin ch\xe0o bạn! M\xecnh l\xe0 Trợ l\xfd AI Palm River.\n\nRất vui được kết nối c\xf9ng bạn! Bạn c\xf3 thể hỏi m\xecnh bất cứ điều g\xec về:\n• Th\xf4ng tin dự \xe1n Palm River & quy hoạch\n• Tra cứu t\xe0i liệu, thủ tục ph\xe1p l\xfd\n• Hỗ trợ giải đ\xe1p nghiệp vụ, kiến thức bất động sản\n\nH\xe3y nhắn tin trực tiếp cho m\xecnh khi bạn cần hỗ trợ nh\xe9!";function aj(a="bot-1"){try{if(!x("bot_state"))return{autoAccept:!1,welcomeMessage:ai};let b=p(a).prepare("SELECT value FROM bot_state WHERE key = 'auto_friend_settings'").get();if(b?.value){let a=JSON.parse(b.value);return{autoAccept:!!a.autoAccept,welcomeMessage:"string"==typeof a.welcomeMessage&&a.welcomeMessage.trim()?a.welcomeMessage:ai}}}catch(a){console.error("[web/db] getAutoFriendSettings error:",a)}return{autoAccept:!1,welcomeMessage:ai}}function ak(a,b="bot-1"){try{if(!x("bot_state"))return!1;let c=aj(b),d={autoAccept:void 0!==a.autoAccept?!!a.autoAccept:c.autoAccept,welcomeMessage:void 0!==a.welcomeMessage?String(a.welcomeMessage):c.welcomeMessage},e=Date.now();return p(b).prepare(`INSERT INTO bot_state (key, value, updated_at) VALUES ('auto_friend_settings', @val, @now)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`).run({val:JSON.stringify(d),now:e}),!0}catch(a){return console.error("[web/db] setAutoFriendSettings error:",a),!1}}}};