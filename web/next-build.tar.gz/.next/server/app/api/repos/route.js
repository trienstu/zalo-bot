(()=>{var a={};a.id=5833,a.ids=[5833],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44178:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>J,patchFetch:()=>I,routeModule:()=>E,serverHooks:()=>H,workAsyncStorage:()=>F,workUnitAsyncStorage:()=>G});var d={};c.r(d),c.d(d,{GET:()=>D,dynamic:()=>C});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(10641),v=c(73024),w=c.n(v),x=c(76760),y=c.n(x),z=c(87550),A=c.n(z),B=c(75779);let C="force-dynamic";async function D(a){try{let{searchParams:b}=new URL(a.url),c=b.get("groupId")||b.get("threadId")||"all",d=b.get("token")||"",e=b.get("category")||"all",f=(b.get("q")||b.get("search")||"").trim(),g=b.get("sort")||"stars",h=Math.max(1,parseInt(b.get("page")||"1",10)),i=Math.max(1,Math.min(60,parseInt(b.get("limit")||"24",10))),j=(h-1)*i,k=function(){for(let a of[process.env.SQLITE_DB_PATH,y().resolve(process.cwd(),"data","bot.db"),y().resolve(process.cwd(),"..","bot","data","bot.db"),y().resolve(process.cwd(),"bot","data","bot.db"),y().resolve(process.cwd(),"..","data","bot.db")].filter(Boolean))if(w().existsSync(a))return a;return y().resolve(process.cwd(),"..","bot","data","bot.db")}();if(!w().existsSync(k))return u.NextResponse.json({repos:[],categories:[],groups:[],pagination:{page:1,limit:i,total:0,totalPages:0},stats:{totalRepos:0,totalStars:0},isLockedGroup:!1});let l=new(A())(k,{readonly:!1});l.exec(`
    CREATE TABLE IF NOT EXISTS group_repos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      thread_id TEXT NOT NULL,
      repo_url TEXT NOT NULL,
      owner TEXT NOT NULL,
      repo_name TEXT NOT NULL,
      full_name TEXT NOT NULL,
      description TEXT,
      stars INTEGER DEFAULT 0,
      forks INTEGER DEFAULT 0,
      language TEXT,
      category TEXT NOT NULL,
      summary_vi TEXT,
      target_audience TEXT,
      shared_by_uid TEXT,
      shared_by_name TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      UNIQUE(thread_id, full_name)
    );
    CREATE INDEX IF NOT EXISTS idx_group_repos_thread ON group_repos(thread_id);
    CREATE INDEX IF NOT EXISTS idx_group_repos_category ON group_repos(category);
    CREATE INDEX IF NOT EXISTS idx_group_repos_created ON group_repos(created_at DESC);
  `);let m=!1,n=null;if(d&&c&&"all"!==c&&(0,B.d)(c,d)){m=!0;let a=l.prepare("SELECT group_id, name FROM bot_groups WHERE group_id = ?").get(c);n={id:c,name:a?.name||"Nh\xf3m ri\xeang",token:d}}let o=[],p=[];if(c&&"all"!==c&&(o.push("gr.thread_id = ?"),p.push(c)),e&&"all"!==e&&(o.push("gr.category = ?"),p.push(e)),f){o.push("(gr.full_name LIKE ? OR gr.description LIKE ? OR gr.summary_vi LIKE ? OR gr.language LIKE ? OR gr.target_audience LIKE ? OR bg.name LIKE ?)");let a=`%${f}%`;p.push(a,a,a,a,a,a)}let q=o.length>0?`WHERE ${o.join(" AND ")}`:"",r="ORDER BY gr.stars DESC, gr.created_at DESC";"newest"===g?r="ORDER BY gr.created_at DESC":"forks"===g?r="ORDER BY gr.forks DESC, gr.created_at DESC":"name"===g?r="ORDER BY gr.full_name ASC":"oldest"===g&&(r="ORDER BY gr.created_at ASC");let s=`
      SELECT COUNT(DISTINCT LOWER(gr.full_name)) as total 
      FROM group_repos gr
      LEFT JOIN bot_groups bg ON bg.group_id = gr.thread_id
      ${q}
    `,t=l.prepare(s).get(...p),v=t?.total||0,x=Math.ceil(v/i),z=`
      SELECT 
        MIN(sub.id) as id,
        sub.repo_url,
        sub.owner,
        sub.repo_name,
        sub.full_name,
        sub.description,
        MAX(sub.stars) as stars,
        MAX(sub.forks) as forks,
        sub.language,
        sub.category,
        sub.summary_vi,
        sub.target_audience,
        sub.shared_by_uid,
        sub.shared_by_name,
        MAX(sub.created_at) as created_at,
        MAX(sub.updated_at) as updated_at,
        GROUP_CONCAT(DISTINCT COALESCE(sub.b_name, 'Nh\xf3m Zalo')) as group_name
      FROM (
        SELECT gr.*, bg.name as b_name
        FROM group_repos gr
        LEFT JOIN bot_groups bg ON bg.group_id = gr.thread_id
        ${q}
        ORDER BY gr.stars DESC, LENGTH(COALESCE(gr.summary_vi, '')) DESC
      ) sub
      GROUP BY LOWER(sub.full_name)
      ${r.replace(/gr\./g,"sub.")}
      LIMIT ? OFFSET ?
    `,C=l.prepare(z).all(...p,i,j),D=`
      SELECT category, COUNT(DISTINCT LOWER(full_name)) as count 
      FROM group_repos gr
      ${c&&"all"!==c?"WHERE gr.thread_id = ?":""}
      GROUP BY category 
      ORDER BY count DESC
    `,E=c&&"all"!==c?l.prepare(D).all(c):l.prepare(D).all(),F=`
      SELECT bg.group_id as id, bg.name, COUNT(DISTINCT LOWER(gr.full_name)) as repoCount
      FROM bot_groups bg
      LEFT JOIN group_repos gr ON gr.thread_id = bg.group_id
      GROUP BY bg.group_id
      ORDER BY repoCount DESC, bg.name ASC
    `,G=l.prepare(F).all().map(a=>({id:a.id,name:a.name,repoCount:Number(a.repoCount)||0,token:(0,B.a)(a.id)})),H=l.prepare(`
      SELECT COUNT(*) as totalRepos, COALESCE(SUM(stars), 0) as totalStars 
      FROM (
        SELECT LOWER(full_name), MAX(stars) as stars
        FROM group_repos
        ${c&&"all"!==c?"WHERE thread_id = ?":""}
        GROUP BY LOWER(full_name)
      )
    `).get(...c&&"all"!==c?[c]:[]);return l.close(),u.NextResponse.json({repos:C,categories:E,groups:G,isLockedGroup:m,currentGroup:n,pagination:{page:h,limit:i,total:v,totalPages:x},stats:{totalRepos:H?.totalRepos||0,totalStars:H?.totalStars||0}})}catch(a){return console.error("[api/repos] Error:",a),u.NextResponse.json({error:a?.message||"Internal Server Error",repos:[]},{status:500})}}let E=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/repos/route",pathname:"/api/repos",filename:"route",bundlePath:"app/api/repos/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/Volumes/SSD NVME/BOT MEMBER ZALO/web/src/app/api/repos/route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:F,workUnitAsyncStorage:G,serverHooks:H}=E;function I(){return(0,g.patchFetch)({workAsyncStorage:F,workUnitAsyncStorage:G})}async function J(a,b,c){var d;let e="/api/repos/route";"/index"===e&&(e="/");let g=await E.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:z,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,resolvedPathname:C}=g,D=(0,j.normalizeAppPath)(e),F=!!(y.dynamicRoutes[D]||y.routes[C]);if(F&&!x){let a=!!y.routes[C],b=y.dynamicRoutes[D];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||E.isDev||x||(G="/index"===(G=C)?"/":G);let H=!0===E.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>E.onRequestError(a,b,d,z)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>E.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&A&&B&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await E.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})},z),b}},l=await E.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",A?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await E.onRequestError(a,b,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},73024:a=>{"use strict";a.exports=require("node:fs")},75779:(a,b,c)=>{"use strict";c.d(b,{a:()=>g,d:()=>h});var d=c(77598),e=c.n(d);let f=process.env.HUB_SECRET||process.env.COOKIE_SECRET||"zalo_hub_secure_salt_2026";function g(a){return a?e().createHmac("sha256",f).update(String(a)).digest("hex").slice(0,16):""}function h(a,b){return!!a&&!!b&&g(a).toLowerCase()===b.trim().toLowerCase()}},76760:a=>{"use strict";a.exports=require("node:path")},77598:a=>{"use strict";a.exports=require("node:crypto")},78335:()=>{},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},87550:a=>{"use strict";a.exports=require("better-sqlite3")},96487:()=>{}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[1331,1692],()=>b(b.s=44178));module.exports=c})();